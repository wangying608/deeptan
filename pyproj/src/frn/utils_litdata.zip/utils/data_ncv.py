r"""
Read multi-omics data (and labels) and split into nested train/val/test sets.

The processed data will be stored in litdata's format.

!!! The input labels (phenotypes) are expected as follows:
    - For REGRESSION task
        + Please keep original values that are not standardized.
        + If you have MULTIPLE traits, please set different columns names in CSV file.
        + _In our pipeline, we standardize/normalize the data after splitting to avoid data leakage._
        + _The method and parameters of standardization/normalization are kept the same as those in training data._
    - For CLASSIFICATION task
        + Please transform labels by one-hot encoder MANUALLY BEFORE input.
        + The length of one-hot vectors is recommended to be **n_categories + 1** for **UNPRECEDENTED labels**.
        + If you have MULTIPLE traits, please concatenate one-hot encoded matrix along the horizontal axis before input.

"""
import os
from typing import Optional, Union, List, Dict
import numpy as np
import polars as pl
from litdata import optimize, StreamingDataLoader, StreamingDataset
from lightning import LightningDataModule
from torch import Tensor
from frn.utils.uni import intersect_lists, read_labels, get_indices_ncv, ProcOnTrainSet


class MyDataset:
    """
    Read data for litdata optimization.

    - `reproduction_mode` is used to determine whether to use the processors fitted before. Please provide `dir_save_processors` if `reproduction_mode` is `True`.
    - `sample_ind_for_proc` is used to select samples for preprocessors fitting. ***If it is `None`, all samples are used.***
    - `dir_save_processors` is used to save data processors that fitted on training data. ***If it is `None`, preprocessing is not performed.***

    """
    def __init__(
            self,
            reproduction_mode: bool,
            paths_omics: Dict[str, str],
            path_label: Optional[str] = None,
            col2use_in_label: Optional[Union[List[str], List[int]]] = None,
            sample_ind_for_proc: Optional[List] = None,
            dir_save_processors: Optional[str] = None,
            target_n_samples: Optional[int] = None,
            seed_resample: int = 42,
            n_fragments: int = 1,
            process_labels: bool = True,
            process_omics: bool = True,
        ):
        super().__init__()

        self.omics_name = sorted(list(paths_omics.keys()))
        self.n_omics = len(self.omics_name)
        self.omics_dfs: Dict[str, pl.DataFrame] = {}
        
        self._pick_shared_samples_in_omics(paths_omics)
        
        self.sample_ids = []
        self.labels_df = None
        self.dim_model_output = None

        if path_label is not None:
            self._pick_shared_samples_in_omics_and_labels(path_label, col2use_in_label)
        else:
            self.sample_ids = self.intersect_ids_in_omics
        
        self.n_samples = len(self.sample_ids)
        self._calc_n_samples2sample(target_n_samples, n_fragments)
        

        if self.n_samples_to_add > 0:
            self._sample_new2add(seed_resample)

        self._proc_omics(process_omics, sample_ind_for_proc, dir_save_processors, reproduction_mode)
        self._proc_labels(process_labels, sample_ind_for_proc, dir_save_processors, reproduction_mode)

        self.omics_data = []
        self.omics_features = []
        for i in range(self.n_omics):
            self.omics_data.append(self.omics_dfs[self.omics_name[i]].drop("ID").to_numpy().astype(np.float32))
            self.omics_features.append(self.omics_dfs[self.omics_name[i]].columns)
        
    def __len__(self):
        return self.n_samples
    
    def __getitem__(self, index):
        omics_data_i = [omics_x[index, :] for omics_x in self.omics_data]
        sample_id_i = self.sample_ids[index]
        if hasattr(self, "label_data"):
            label_data_i = self.label_data[index, :]
            data_o = {"index": index, "label": label_data_i, "omics": omics_data_i, "id": sample_id_i}
        else:
            data_o = {"index": index, "omics": omics_data_i, "id": sample_id_i}
        return data_o
    
    def _pick_shared_samples_in_omics(self, paths_omics: Dict[str, str]):
        original_omics_IDs = []
        for i in range(self.n_omics):
            self.omics_dfs[self.omics_name[i]] = pl.read_csv(paths_omics[self.omics_name[i]], schema_overrides={"ID": pl.Utf8})
            original_omics_IDs.append(self.omics_dfs[self.omics_name[i]].select("ID").to_series().to_list())
        
        intersect_ids_in_omics, _indices = intersect_lists(original_omics_IDs)
        for i in range(self.n_omics):
            self.omics_dfs[self.omics_name[i]] = self.omics_dfs[self.omics_name[i]][_indices[i],:].sort("ID")
        
        self.intersect_ids_in_omics = intersect_ids_in_omics
    
    def _pick_shared_samples_in_omics_and_labels(self, path_label: str, col2use_in_label: Optional[Union[List[str], List[int]]]):
        labels_df, dim_model_output, sample_ids_in_labels = read_labels(path_label, col2use_in_label)
        intersect_ids, _indices = intersect_lists([self.intersect_ids_in_omics, sample_ids_in_labels])
        
        for i in range(self.n_omics):
            self.omics_dfs[self.omics_name[i]] = self.omics_dfs[self.omics_name[i]][_indices[0],:].sort("ID")
        labels_df = labels_df[_indices[1],:].sort("ID")

        self.sample_ids = intersect_ids
        self.labels_df = labels_df
        self.model_output_dim = dim_model_output
    
    def _calc_n_samples2sample(self, target_n_samples: Optional[int], n_fragments: int):
        n_samples_to_add = 0
        match target_n_samples:
            case None:
                if n_fragments > 1:
                    if self.n_samples % n_fragments != 0:
                        n_samples_to_add = n_fragments - (self.n_samples % n_fragments)
            case x if x > self.n_samples:
                n_samples_to_add = x - self.n_samples
            case _:
                raise Warning("target_n_samples must be larger than the number of samples")
        self.n_samples_to_add = n_samples_to_add
        self.n_samples_target = self.n_samples + n_samples_to_add
    
    def _sample_new2add(self, seed_resample: int):
        # Generate random indices to add
        np.random.seed(seed_resample)
        new_indices: list[int] = np.random.choice(self.n_samples, self.n_samples_to_add, replace=True).tolist()
        self.n_samples = self.n_samples_target
        self.sample_ids = self.sample_ids + [self.sample_ids[i] for i in new_indices]
        
        if self.labels_df is not None:
            self.labels_df = self.labels_df.vstack(self.labels_df[new_indices,:])

        for i in range(self.n_omics):
            self.omics_dfs[self.omics_name[i]] = self.omics_dfs[self.omics_name[i]].vstack(self.omics_dfs[self.omics_name[i]][new_indices,:])
    
    def _proc_omics(self, process_omics: bool, sample_ind_for_proc: Optional[List[int]], dir_save_processors: Optional[str], reproduction_mode: bool):
        if process_omics:
            if reproduction_mode and dir_save_processors is not None:
                if os.path.exists(dir_save_processors):
                    for i in range(self.n_omics):
                        _loaded_proc = ProcOnTrainSet(self.omics_dfs[self.omics_name[i]], None)
                        _loaded_proc.load_run_processors(dir_save_processors, f'data_processors_for_omics_{self.omics_name[i]}.pkl')
                        self.omics_dfs[self.omics_name[i]] = _loaded_proc._df
                else:
                    raise FileNotFoundError(f"Processor files for omics data are not found in {dir_save_processors}")
            else:
                for i in range(self.n_omics):
                    _tmp_proc = ProcOnTrainSet(self.omics_dfs[self.omics_name[i]], sample_ind_for_proc)
                    _tmp_proc.pr_impute(strategy="mean")
                    _tmp_proc.pr_minmax()
                    if dir_save_processors is not None:
                        _tmp_proc.save_processors(dir_save_processors, f'data_processors_for_omics_{self.omics_name[i]}.pkl')
                    self.omics_dfs[self.omics_name[i]] = _tmp_proc._df
    
    def _proc_labels(self, process_labels: bool, sample_ind_for_proc: Optional[List[int]], dir_save_processors: Optional[str], reproduction_mode: bool):
        if self.labels_df is not None and process_labels:
            if reproduction_mode and dir_save_processors is not None:
                if os.path.exists(dir_save_processors):
                    labels_processor = ProcOnTrainSet(self.labels_df, None)
                    labels_processor.load_run_processors(dir_save_processors, 'data_processors_for_labels.pkl')
                    self.labels_df = labels_processor._df
                else:
                    raise FileNotFoundError(f"Processor files for labels are not found in {dir_save_processors}")
            else:
                labels_processor = ProcOnTrainSet(self.labels_df, sample_ind_for_proc)
                labels_processor.pr_impute(strategy="mean")
                labels_processor.pr_minmax()
                if dir_save_processors is not None:
                    labels_processor.save_processors(dir_save_processors, 'data_processors_for_labels.pkl')
                labels_df = labels_processor._df
                self.label_data = labels_df.drop("ID").to_numpy().astype(np.float32)
                self.label_features = labels_df.columns


def optimize_data_ncv(
        output_dir: str,
        k_outer: int,
        k_inner: int,
        paths_omics: Dict[str, str],
        path_label: Optional[str] = None,
        col2use_in_labels: Optional[Union[List[str], List[int]]] = None,
        process_labels: bool = True,
        process_omics: bool = True,
        fragment_elem_ids: Optional[List[List[int]]] = None,
        seed_permut: int = 42,
        seed_resample: int = 42,
        compression: Optional[str] = "zstd",
        n_workers: int = 1,
    ):
    """
    Args:
        `output_dir`: Directory to save the optimized data.
        `k_outer`: Number of outer folds.
        `k_inner`: Number of inner folds.
        `paths_omics`: List of paths to omics data.
        `path_label`: Path to label data.
        `col2use_in_labels`: List of columns (of label data) to use.
        `process_labels`: Whether to preprocess labels.
        `process_omics`: Whether to preprocess omics.
        `fragment_elem_ids`: List of list of indices of elements in each fragment. For nested cross validation with 10 outer folds and 5 inner folds, this should be a list of 50 lists of indices.
        `seed_permut`: Seed for permutation.
        `seed_resample`: Seed for resampling.
        `compression`: Compression algorithm.
        `n_workers`: Number of workers.
    """
    if fragment_elem_ids is None:
        n_fragments = int(k_outer * k_inner)
        tmp_data_init = MyDataset(False, paths_omics, path_label, col2use_in_labels, None, None, None, seed_resample, n_fragments, False, False)

        # Permutate samples
        np.random.seed(seed_permut)
        _indices = np.random.permutation(len(tmp_data_init))
        fragments = np.array_split(_indices, n_fragments)
        fragments = [i.tolist() for i in fragments]
    else:
        fragments = fragment_elem_ids
        n_fragments = len(fragment_elem_ids)
        assert k_outer * k_inner == n_fragments

    for xo in range(k_outer):
        for xi in range(k_inner):
            fr_indices_trn, fr_indices_val, fr_indices_test = get_indices_ncv(k_outer, k_inner, xo, xi)
            indices_trn_samples = np.concatenate([fragments[i] for i in fr_indices_trn]).tolist()
            indices_val_samples = np.concatenate([fragments[i] for i in fr_indices_val]).tolist()
            indices_tst_samples = np.concatenate([fragments[i] for i in fr_indices_test]).tolist()
            dir_xoxi = os.path.join(output_dir, f"ncv_test_{xo}_val_{xi}")
            os.makedirs(dir_xoxi, exist_ok=True)
            
            #
            dataset_xoxi = MyDataset(False, paths_omics, path_label, col2use_in_labels, indices_trn_samples, dir_xoxi, None, seed_resample, n_fragments, process_labels, process_omics)
            
            # Start optimizing
            optimize(
                fn = dataset_xoxi.__getitem__,
                inputs = indices_trn_samples,
                output_dir = os.path.join(dir_xoxi, "train"),
                chunk_bytes = "256MB",
                compression = compression,
                num_workers = n_workers,
            )
            optimize(
                fn = dataset_xoxi.__getitem__,
                inputs = indices_val_samples,
                output_dir = os.path.join(dir_xoxi, "valid"),
                chunk_bytes = "256MB",
                compression = compression,
                num_workers = n_workers,
            )
            optimize(
                fn = dataset_xoxi.__getitem__,
                inputs = indices_tst_samples,
                output_dir = os.path.join(dir_xoxi, "test"),
                chunk_bytes = "256MB",
                compression = compression,
                num_workers = n_workers,
            )
    
    if path_label is not None:
        _, dim_model_output, _ = read_labels(path_label, col2use_in_labels)
        df_output_dim = pl.DataFrame(data={"model_output_dim": [dim_model_output]})
        df_output_dim.write_csv(os.path.join(output_dir, "model_output_dim.csv"))
    
    return None


def optimize_data_external(
        output_dir: str,
        paths_omics: Dict[str, str],
        path_label: Optional[str] = None,
        col2use_in_labels: Optional[Union[List[str], List[int]]] = None,
        process_labels: bool = True,
        process_omics: bool = True,
        reproduction_mode: bool = False,
        dir_processors: Optional[str] = None,
        compression: Optional[str] = "zstd",
        n_workers: int = 1,
    ):
    """
    Optimize data for external use.
    """
    dataset_ext = MyDataset(
        reproduction_mode=reproduction_mode,
        paths_omics=paths_omics,
        path_label=path_label,
        col2use_in_label=col2use_in_labels,
        dir_save_processors=dir_processors,
        process_labels=process_labels,
        process_omics=process_omics,
    )
    optimize(
        fn = dataset_ext.__getitem__,
        inputs = range(len(dataset_ext)),
        output_dir = output_dir,
        chunk_bytes = "256MB",
        compression = compression,
        num_workers = n_workers,
    )


class MyDataModule4Train(LightningDataModule):
    """
    LightningDataModule for training models with LitData.
    
    Args:
    - `litdata_dir` (str): Directory containing the LitData fragments.
    - `which_outer_testset` (int): Index of the outer test set fold.
    - `which_inner_valset` (int): Index of the inner validation set fold.
    - `batch_size` (int): Batch size for training and evaluation.
    """
    def __init__(
            self,
            litdata_dir: str,
            which_outer_testset: int,
            which_inner_valset: int,
            batch_size: int,
            n_workers: int = 2,
        ):
        super().__init__()
        self.litdata_dir = litdata_dir
        self.which_outer_testset = which_outer_testset
        self.which_inner_valset = which_inner_valset
        self.batch_size = batch_size
        self.n_workers = n_workers

    def setup(self, stage=None):
        self.dataloder_trn, self.dataloader_val, self.dataloader_test = self.read_litdata_ncv()
    
    def train_dataloader(self):
        return self.dataloder_trn
    def val_dataloader(self):
        return self.dataloader_val
    def test_dataloader(self):
        return self.dataloader_test
    
    def read_litdata_ncv(self):
        """
        Read litdata from directories and return dataloaders for NCV.
        """
        dir_train, dir_valid, dir_test = self.get_dir_ncv_litdata()
        dataloader_train = StreamingDataLoader(StreamingDataset(dir_train), batch_size=self.batch_size, num_workers=self.n_workers)
        dataloader_valid = StreamingDataLoader(StreamingDataset(dir_valid), batch_size=self.batch_size, num_workers=self.n_workers)
        dataloader_test = StreamingDataLoader(StreamingDataset(dir_test), batch_size=self.batch_size, num_workers=self.n_workers)
        return dataloader_train, dataloader_valid, dataloader_test
    
    def get_dir_ncv_litdata(self):
        dir_xoi = os.path.join(self.litdata_dir, f"ncv_test_{self.which_outer_testset}_val_{self.which_inner_valset}")
        dir_trn = os.path.join(dir_xoi, "train")
        dir_val = os.path.join(dir_xoi, "valid")
        dir_tst = os.path.join(dir_xoi, "test")
        return dir_trn, dir_val, dir_tst


class MyDataModule4Uni(LightningDataModule):
    """
    LightningDataModule for predicting/testing.

    Args:
    - `litdata_dir` (str): Directory containing the LitData for prediction.
    - `batch_size` (int): Batch size for prediction.
    """
    def __init__(
            self,
            litdata_dir: str,
            batch_size: int,
            n_workers: int = 2,
        ):
        super().__init__()
        self.litdata_dir = litdata_dir
        self.batch_size = batch_size
        self.n_workers = n_workers
    
    def setup(self, stage=None):
        self.dataloader_xxx = StreamingDataLoader(StreamingDataset(self.litdata_dir), batch_size=self.batch_size, num_workers=self.n_workers)
    
    def predict_dataloader(self):
        return self.dataloader_xxx

    # def test_dataloader(self):
    #     return self.dataloader_x


def auto_proc_feat4trn(in_array: np.ndarray, threshold_ptp: float=100.0):
    """
    Args:
    - `in_array` (np.ndarray): Input array with shape (n_features, n_samples).
    - `threshold_ptp` (float): Threshold for the range.

    Steps:
    1. Remove feature if its range is similar to zero.
    2. Apply scale and log2 transformation to each feature in the training set. (Apply log2 transformation if the range of the array is larger than the threshold.)
    
    """
    values_min = np.min(in_array, axis=1)
    values_max = np.max(in_array, axis=1)
    values_ptp = values_max - values_min

    out_array = np.copy(in_array) + 1e-4
    feat2rm = np.where(values_ptp < 1e-3)[0]
    
    for i in range(in_array.shape[0]):
        if i in feat2rm:
            continue
        if values_ptp[i] > threshold_ptp:
            # Apply log2 transformation
            out_array[i, :] = np.log2(out_array[i, :])
    
    out_array = np.delete(out_array, feat2rm, axis=0)

    values_min = np.min(out_array, axis=1)
    values_max = np.max(out_array, axis=1)
    # out_array = (out_array - values_min) / (values_max - values_min)
    out_array = (out_array - values_min[:, None]) / (values_max[:, None] - values_min[:, None])
    return out_array, values_min, values_max, feat2rm


def omics_tensor_list_to_np(batch: List[Tensor]):
    concatenated = np.concatenate([ts.numpy() for ts in batch], axis=None)
    return concatenated


def read_litdata_ncv_for_mi(
        litdata_dir: str,
        output_dir: str,
        which_outer_test: int,
        which_inner_val: int,
        threshold_ptp: float=100.0,
        path_excutable: Optional[str] = None,
        thre_sd: float = 0.05,
        thre_pcc: float = 0.9,
        thre_mi: float = 0.2,
    ) -> None:
    """
    Read specific NCV litdata from directories and calculate MI for each inner training set.
    """
    # Check if path_excutable is None
    if path_excutable is None:
        path_excutable = os.path.join(os.path.dirname(__file__), "mi2graph")
    if not os.path.exists(path_excutable):
        raise FileNotFoundError(f"Executable file not found: {path_excutable}")

    # Read litdata
    dir_xoi = os.path.join(litdata_dir, f"ncv_test_{which_outer_test}_val_{which_inner_val}")
    dataloader_trn = StreamingDataLoader(StreamingDataset(os.path.join(dir_xoi, "train")))

    # Run the compiled MI-based proccessing procedure on training data
    trnset_npy_dir = os.path.join(output_dir, "tmp_trnset")
    os.makedirs(trnset_npy_dir, exist_ok=True)
    mi_net_dir = os.path.join(output_dir, "mi_net_for_traindataset")
    os.makedirs(mi_net_dir, exist_ok=True)
    
    # Read (multiple) omics' data from dataloader_trn and save it to a matrix, then save the matrix to a NPY file.
    trn_data_matrix = [omics_tensor_list_to_np(batch['omics']) for batch in dataloader_trn]
    trn_data_matrix = np.array(trn_data_matrix).astype(np.float64).transpose()
    
    # Scale and log2 transformation for each feature
    trn_data_matrix, values_min, values_max, feat2rm = auto_proc_feat4trn(trn_data_matrix, threshold_ptp)

    # Check if the matrix contains 'None' value
    if np.any(np.isnan(trn_data_matrix)):
        raise ValueError("The matrix contains 'None' value.")
    
    # Save the matrix to a NPY file
    path_npy = os.path.join(trnset_npy_dir, f"trn_{which_outer_test}_{which_inner_val}.npy")
    np.save(path_npy, trn_data_matrix)
    
    # Save the min and max values for scaling back & scaling validation and testing dataset
    path_range = os.path.join(mi_net_dir, f"trn_{which_outer_test}_{which_inner_val}_range.npz")
    np.savez(path_range, values_min=values_min, values_max=values_max, feat2rm=feat2rm)
    
    # Run
    path_npz = os.path.join(mi_net_dir, f"trn_{which_outer_test}_{which_inner_val}.npz")
    cmd_mi = f"{path_excutable} -i {path_npy} -o {path_npz} --thresd {thre_sd} --threpcc {thre_pcc} --thremi {thre_mi}"
    print("\nRUNNING: ", cmd_mi, "\n")
    os.system(cmd_mi)

    os.remove(path_npy)
    return None
